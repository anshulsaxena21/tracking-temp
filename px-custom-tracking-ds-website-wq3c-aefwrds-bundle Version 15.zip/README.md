# PX Custom Tracking & DS Website WQ3C Aefwrds

Exported from FigmaSpecs.

- design-data/complete-design.json: full extracted node tree and asset manifest
- design-data/layer-descriptions.json: layer measurements, layout, typography and appearance
- design-data/layer-descriptions.csv: spreadsheet-friendly layer inventory
- design-data/design-tokens.css: extracted design tokens
- assets/: downloaded image and vector assets
- Frame screenshots were not available for this export; the complete design JSON and layer documentation are included.
