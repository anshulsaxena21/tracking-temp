# FigmaSpecs AI Handoff Setup

## 1. Upload the export to GitHub
Create or choose a repository and upload the complete FigmaSpecs export. Preserve reference-frames/, assets/, design-data/ and code/ folders and all filenames.

## 2. Connect GitHub to ChatGPT
Connect GitHub from ChatGPT Settings > Apps / Connectors and authorize access to the target repository. Ask ChatGPT to inspect the repository before editing.

## 3. Upload design context to ChatGPT
Attach all reference-frame PNGs and these files: design-data/complete-design.json, frame-screenshots.json, layer-descriptions.json, design-tokens.css and assets/asset-manifest.json. For large projects, upload in manageable batches. Keep GitHub as the source of truth for the full asset library.

## 4. Start implementation
Copy AI-IMPLEMENTATION-PROMPT.md into the same ChatGPT conversation. Ask ChatGPT to inspect the repository and explain its plan before editing.

## 5. Verify
Ask ChatGPT to run the build/tests, check asset paths and responsive layouts, and compare rendered pages against supplied screenshots. Review changes before accepting them.

Note: Connector availability and permissions depend on your account and workspace. Never share private tokens in chat or commit secrets to GitHub.