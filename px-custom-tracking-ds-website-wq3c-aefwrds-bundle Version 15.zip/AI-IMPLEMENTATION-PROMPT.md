# FigmaSpecs — AI Website Implementation Brief

Act as a senior frontend engineer, UI/UX engineer and design-systems specialist. Recreate the supplied Figma design as a responsive, production-quality website.

## Inspect before coding
1. Inspect the connected GitHub repository, branch, package scripts, framework, dependencies, routes and existing components.
2. Review every PNG in reference-frames/ and map it using design-data/frame-screenshots.json.
3. Read design-data/complete-design.json for the complete Figma node tree.
4. Read design-data/layer-descriptions.json and layer-descriptions.csv for hierarchy, measurements, Auto Layout and typography.
5. Read design-data/design-tokens.css and use its tokens.
6. Inspect assets/asset-manifest.json and use original files in assets/images/ and assets/vectors/.
7. Review code/ as reference material, not as an assumed complete production implementation.

## Implementation requirements
- Explain repository architecture, available frames, assets, tokens and missing inputs before editing; provide a concise plan.
- Preserve the existing framework, architecture, working features and conventions. Do not rewrite unrelated code.
- Build reusable, focused components with semantic HTML, accessibility and maintainable CSS.
- Match dimensions, spacing, typography, colors, borders, shadows, radii, image crops, alignment and visual hierarchy closely.
- Use supplied assets and fonts. Never substitute placeholders, stock imagery, emoji or invented logos when originals exist.
- Implement responsive desktop, tablet and mobile layouts. Where responsive references are absent, adapt carefully without changing the design language.
- Do not invent important business logic or interactions. Ask when requirements are unclear.
- Avoid duplicated CSS, oversized components, unnecessary dependencies, dead code, unexplained absolute positioning and console errors.

## Verification
Run the existing build and tests. Check imports, missing assets, console errors, accessibility, interactions, overflow and responsive layouts. Compare rendered pages against supplied screenshots at matching viewport sizes and correct mismatches section by section. Never claim pixel-perfect accuracy without actual visual comparison.

## GitHub safety and final report
Inspect the working tree and target branch before changes. Preserve unrelated work. Report exactly what changed and never claim a commit, push or deployment unless it succeeded.
At completion, report completed sections, components, asset usage, responsive status, build/test results, remaining visual differences, missing assets and questions.

## Project context
Figma project: PX Custom Tracking & DS Website WQ3C Aefwrds
Detected layers: 458; image fills: 18; vector layers: 53

Primary rule: screenshots are the visual reference, Figma JSON/layer data is structural evidence, and supplied asset files are the source of truth. Achieve visual fidelity without sacrificing code quality or existing functionality.